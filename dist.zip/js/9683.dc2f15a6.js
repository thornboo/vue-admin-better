"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["9683"], {
92332: (function (module, __unused_webpack_exports, __webpack_require__) {
module.exports = __webpack_require__.p + "static/right.9d354013c83fa357.jpg";

}),

}]);